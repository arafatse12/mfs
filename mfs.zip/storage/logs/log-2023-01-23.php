<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-23 09:34:11 --> 404 Page Not Found: Job/insert_job
