<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
ERROR - 2023-01-29 21:22:53 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:24:07 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:24:23 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:24:49 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:25:14 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:28:58 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:29:55 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:30:01 --> 404 Page Not Found: Job-apply/index
ERROR - 2023-01-29 21:31:48 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:39:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '''' at line 1 - Invalid query: delete from apply_job where id ''
ERROR - 2023-01-29 21:39:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '''' at line 1 - Invalid query: delete from apply_job where id ''
ERROR - 2023-01-29 21:45:07 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:45:28 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:47:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: delete from apply_job where id=
ERROR - 2023-01-29 21:47:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: delete from apply_job where id=
ERROR - 2023-01-29 21:48:18 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:49:12 --> Severity: error --> Exception: Call to undefined method Booking::input() D:\laragon\www\mfs\application\controllers\admin\Booking.php 116
ERROR - 2023-01-29 21:51:55 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:54:50 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:55:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: delete from apply_job where id=
ERROR - 2023-01-29 21:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:55:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: delete from apply_job where id=
ERROR - 2023-01-29 21:55:54 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:55:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: delete from apply_job where id=
ERROR - 2023-01-29 21:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:58:21 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:58:46 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 21:58:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: delete from apply_job where id=
ERROR - 2023-01-29 22:00:50 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:01:11 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:02:06 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:02:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: delete from apply_job where id=
ERROR - 2023-01-29 22:03:36 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:05:00 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-29 22:26:53 --> 404 Page Not Found: Booking/file_download
ERROR - 2023-01-29 22:29:09 --> 404 Page Not Found: Booking/file_download
ERROR - 2023-01-29 22:36:07 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-29 22:40:08 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-29 22:48:31 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-29 22:49:11 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:53:34 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:55:23 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:55:53 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:56:17 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:56:36 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:57:10 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:58:18 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-29 22:59:11 --> 404 Page Not Found: Assets/js
