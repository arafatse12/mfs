<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-22 09:45:51 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\laragon\www\mfs\application\controllers\user\Job.php 134
ERROR - 2023-01-22 09:46:03 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\laragon\www\mfs\application\controllers\user\Job.php 134
ERROR - 2023-01-22 09:46:26 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\laragon\www\mfs\application\controllers\user\Job.php 134
ERROR - 2023-01-22 09:54:17 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\laragon\www\mfs\application\controllers\user\Job.php 135
