<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-21 11:33:20 --> 404 Page Not Found: Css/fontawesome.min.css
ERROR - 2023-01-21 11:33:20 --> 404 Page Not Found: Css/all.min.css
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Css/style.css
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Js/script.js
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/logo-icon.png
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/7.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/logo.png
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/6.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/8.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/10.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/11.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/5.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/12.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/9.jpg
ERROR - 2023-01-21 11:33:21 --> 404 Page Not Found: Img/1660053769service-26.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/5.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/6.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/7.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/8.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/11.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/10.jpg
ERROR - 2023-01-21 11:33:27 --> 404 Page Not Found: Img/9.jpg
ERROR - 2023-01-21 11:33:41 --> 404 Page Not Found: Undefineduser/service
ERROR - 2023-01-21 11:34:07 --> 404 Page Not Found: Js/script.js
ERROR - 2023-01-21 11:34:07 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:34:07 --> 404 Page Not Found: Img/logo.png
ERROR - 2023-01-21 11:34:07 --> 404 Page Not Found: Img/logo-icon.png
ERROR - 2023-01-21 11:34:07 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:34:07 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:34:07 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/5.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/6.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/7.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/11.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/10.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/8.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/9.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/12.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/1660053769service-26.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/1660053807service-27.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/1660053900service-28.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/6.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/5.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:34:08 --> 404 Page Not Found: Undefineduser/service
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Css/fontawesome.min.css
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Css/all.min.css
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Js/script.js
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Css/style.css
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/logo.png
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/logo-icon.png
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/5.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/8.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/7.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/10.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/1660053807service-27.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/12.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/1660053900service-28.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/9.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/11.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/6.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/1660053769service-26.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:34:22 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:34:23 --> 404 Page Not Found: Undefineduser/service
ERROR - 2023-01-21 11:38:24 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:38:24 --> 404 Page Not Found: Js/script.js
ERROR - 2023-01-21 11:38:24 --> 404 Page Not Found: Img/logo-icon.png
ERROR - 2023-01-21 11:38:24 --> 404 Page Not Found: Img/logo.png
ERROR - 2023-01-21 11:38:24 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:38:24 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/5.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/7.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/8.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/6.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/9.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/10.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/11.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/12.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/1660053900service-28.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/1660053807service-27.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Img/1660053769service-26.jpg
ERROR - 2023-01-21 11:38:25 --> 404 Page Not Found: Undefineduser/service
ERROR - 2023-01-21 11:39:32 --> 404 Page Not Found: Js/script.js
ERROR - 2023-01-21 11:39:32 --> 404 Page Not Found: Img/logo.png
ERROR - 2023-01-21 11:39:32 --> 404 Page Not Found: Img/logo-icon.png
ERROR - 2023-01-21 11:39:32 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:39:32 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:39:32 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/8.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/5.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/6.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/9.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/7.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/10.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/12.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/1660053900service-28.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/1660053807service-27.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/1660053769service-26.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Img/11.jpg
ERROR - 2023-01-21 11:39:33 --> 404 Page Not Found: Undefineduser/service
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/logo.png
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/logo-icon.png
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/2.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/1.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Js/script.js
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/3.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/4.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/6.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/7.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/5.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/8.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/10.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/12.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/1660053900service-28.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/9.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/11.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/1660053769service-26.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Img/1660053807service-27.jpg
ERROR - 2023-01-21 11:39:55 --> 404 Page Not Found: Undefineduser/service
ERROR - 2023-01-21 12:21:06 --> 404 Page Not Found: Css/fontawesome.min.css
ERROR - 2023-01-21 12:21:06 --> 404 Page Not Found: Css/all.min.css
ERROR - 2023-01-21 12:21:06 --> 404 Page Not Found: Css/style.css
ERROR - 2023-01-21 12:21:08 --> 404 Page Not Found: Img/favicon.png
ERROR - 2023-01-21 12:21:10 --> 404 Page Not Found: Css/fontawesome.min.css
ERROR - 2023-01-21 12:21:10 --> 404 Page Not Found: Css/all.min.css
ERROR - 2023-01-21 12:21:10 --> 404 Page Not Found: Css/style.css
ERROR - 2023-01-21 12:21:38 --> 404 Page Not Found: Css/all.min.css
ERROR - 2023-01-21 12:21:38 --> 404 Page Not Found: Css/fontawesome.min.css
ERROR - 2023-01-21 12:21:38 --> 404 Page Not Found: Css/style.css
ERROR - 2023-01-21 12:21:42 --> 404 Page Not Found: Img/favicon.png
ERROR - 2023-01-21 12:22:47 --> 404 Page Not Found: Css/fontawesome.min.css
ERROR - 2023-01-21 12:22:47 --> 404 Page Not Found: Css/all.min.css
ERROR - 2023-01-21 12:22:47 --> 404 Page Not Found: Css/style.css
ERROR - 2023-01-21 12:22:49 --> 404 Page Not Found: Img/favicon.png
ERROR - 2023-01-21 12:23:10 --> 404 Page Not Found: Mfs/css
ERROR - 2023-01-21 12:23:10 --> 404 Page Not Found: Mfs/css
ERROR - 2023-01-21 12:23:10 --> 404 Page Not Found: Mfs/css
ERROR - 2023-01-21 12:23:11 --> 404 Page Not Found: Img/favicon.png
ERROR - 2023-01-21 12:23:24 --> 404 Page Not Found: Mfs/css
ERROR - 2023-01-21 12:23:26 --> 404 Page Not Found: Mfs/css
ERROR - 2023-01-21 12:24:36 --> 404 Page Not Found: Img/favicon.png
ERROR - 2023-01-21 12:32:21 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 12:33:31 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 12:37:27 --> Query error: Column 'cookie_name' cannot be null - Invalid query: INSERT INTO `cookies` (`lang_type`, `modules`, `cookie_name`) VALUES ('en', 'website', NULL)
ERROR - 2023-01-21 12:37:50 --> Query error: Column 'cookie_name' cannot be null - Invalid query: INSERT INTO `cookies` (`lang_type`, `modules`, `cookie_name`) VALUES ('en', 'website', NULL)
ERROR - 2023-01-21 12:37:55 --> Query error: Column 'cookie_name' cannot be null - Invalid query: INSERT INTO `cookies` (`lang_type`, `modules`, `cookie_name`) VALUES ('en', 'website', NULL)
ERROR - 2023-01-21 12:43:15 --> Query error: Column 'cookie_name' cannot be null - Invalid query: INSERT INTO `cookies` (`lang_type`, `modules`, `cookie_name`) VALUES ('en', 'website', NULL)
ERROR - 2023-01-21 12:43:51 --> Query error: Column 'cookie_name' cannot be null - Invalid query: INSERT INTO `cookies` (`lang_type`, `modules`, `cookie_name`) VALUES ('en', 'website', NULL)
ERROR - 2023-01-21 12:45:12 --> Query error: Column 'cookie_name' cannot be null - Invalid query: INSERT INTO `cookies` (`lang_type`, `modules`, `cookie_name`) VALUES ('en', 'website', NULL)
ERROR - 2023-01-21 12:48:33 --> Severity: error --> Exception: syntax error, unexpected '>' D:\laragon\www\mfs\application\views\user\includes\header.php 85
ERROR - 2023-01-21 12:52:42 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\laragon\www\mfs\application\views\user\includes\navbar.php 117
ERROR - 2023-01-21 13:06:36 --> 404 Page Not Found: Uploads/profile_img
ERROR - 2023-01-21 13:07:06 --> Query error: Expression #2 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.SP.sub_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `SP`.*, `U`.`name`, `S`.`subscription_name`, `SD`.`expiry_date_time`, `SD`.`paid_status`, `SD`.`id` as `subscription_details_id`
FROM `subscription_payment` `SP`
LEFT JOIN `subscription_details` `SD` ON `SD`.`subscription_id`=`SP`.`subscription_id`
LEFT JOIN `subscription_fee` `S` ON `S`.`id`=`SP`.`subscription_id`
LEFT JOIN `providers` `U` ON `U`.`id`=`SP`.`subscriber_id`
WHERE `SP`.`tokenid` = 'Offline Payment'
GROUP BY `SP`.`id`
ORDER BY `SP`.`id` DESC
ERROR - 2023-01-21 13:07:06 --> Severity: error --> Exception: Call to a member function result_array() on bool D:\laragon\www\mfs\application\models\Admin_model.php 1141
ERROR - 2023-01-21 13:13:41 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 13:15:50 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-21 13:16:53 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `categories_lang` (`category_id`, `lang_type`, `category_name`) VALUES (2, 'en', 'Carpentry Works')
ERROR - 2023-01-21 13:16:56 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-21 13:17:34 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `categories_lang` (`category_id`, `lang_type`, `category_name`) VALUES (3, 'en', 'Electrical Works')
ERROR - 2023-01-21 13:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-21 13:17:46 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-21 13:19:00 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `categories_lang` (`category_id`, `lang_type`, `category_name`) VALUES ('1', 'en', 'Painting Works')
ERROR - 2023-01-21 13:19:16 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `categories_lang` (`category_id`, `lang_type`, `category_name`) VALUES ('2', 'en', 'Carpentry Works')
ERROR - 2023-01-21 13:19:32 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `categories_lang` (`category_id`, `lang_type`, `category_name`) VALUES ('3', 'en', 'Electrical Works')
ERROR - 2023-01-21 14:12:13 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 14:12:43 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 14:13:06 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 14:13:48 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 14:16:39 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 14:17:20 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 14:17:54 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:05:46 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:06:14 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:06:44 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:07:24 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:08:02 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:08:32 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:44:37 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:45:00 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:46:50 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:47:51 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:48:00 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:48:29 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 15:48:59 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 16:01:48 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 16:02:18 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 16:04:32 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 16:04:54 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 16:05:24 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 16:09:54 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 16:10:24 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 16:49:24 --> 404 Page Not Found: Ckeditorjs/index
ERROR - 2023-01-21 16:49:47 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 16:54:35 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 16:58:51 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `blog_posts` (`title`, `lang_id`, `category_id`, `slug`, `summary`, `keywords`, `tags`, `content`, `image_small`, `image_default`, `url`, `storage`, `status`, `createdBy`) VALUES ('How to Fix a Computer in Just 3 Steps?', '28', '1', 'How to Fix a Computer in Just 3 Steps?', 'How to Fix a Computer in Just 3 Steps?', '', '', '<p>How to Fix a Computer in Just 3 Steps?</p>', 'uploads/blogs/16743005311660053807service-27.jpg', 'uploads/blogs/16743005311660053807service-27.jpg', 'how-to-fix-a-computer-in-just-3-steps', 'local', 1, '1')
ERROR - 2023-01-21 16:59:11 --> 404 Page Not Found: Uploads/profile_img
ERROR - 2023-01-21 16:59:30 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `blog_posts` (`title`, `lang_id`, `category_id`, `slug`, `summary`, `keywords`, `tags`, `content`, `image_small`, `image_default`, `url`, `storage`, `status`, `createdBy`) VALUES ('How to Fix a Computer in Just 3 Steps?', '28', '1', 'How to Fix a Computer in Just 3 Steps?', 'How to Fix a Computer in Just 3 Steps?', 'How to Fix a Computer in Just 3 Steps?', '', '<p>How to Fix a Computer in Just 3 Steps?</p>', 'uploads/blogs/16743005701660053807service-27.jpg', 'uploads/blogs/16743005701660053807service-27.jpg', 'how-to-fix-a-computer-in-just-3-steps', 'local', 1, '1')
ERROR - 2023-01-21 16:59:34 --> 404 Page Not Found: Uploads/profile_img
ERROR - 2023-01-21 16:59:37 --> 404 Page Not Found: Uploads/profile_img
ERROR - 2023-01-21 17:00:20 --> 404 Page Not Found: Uploads/profile_img
ERROR - 2023-01-21 17:00:42 --> 404 Page Not Found: Uploads/profile_img
ERROR - 2023-01-21 18:07:01 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:08:34 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:09:41 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:10:14 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:13:37 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:15:04 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:15:13 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:15:23 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:15:39 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:16:40 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:18:31 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:19:47 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 18:25:52 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:26:52 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:26:53 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-21 18:36:00 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-21 18:36:18 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:36:22 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:36:27 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:38:08 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:39:14 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:39:38 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-21 18:41:03 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:41:06 --> 404 Page Not Found: Assets/js
ERROR - 2023-01-21 18:42:43 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:45:17 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 18:47:36 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 20:04:15 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 21:29:52 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:32:05 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:32:07 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:32:14 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:32:34 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:33:34 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:34:08 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:35:03 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:35:58 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:37:06 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:39:43 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:39:48 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:39:56 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:40:44 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:40:55 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:41:19 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:41:43 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:42:39 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:43:11 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:43:39 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:44:00 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:44:59 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:45:19 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:45:34 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 21:45:47 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 22:27:33 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'truelysell.f.currency_code'; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT sum(fee) as paid_amt, `currency_code`
FROM `subscription_details_history` as `s`
JOIN `subscription_fee` as `f` ON `f`.`id`=`s`.`subscription_id`
ERROR - 2023-01-21 22:28:41 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 22:29:20 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 22:30:15 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 22:30:55 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 22:31:34 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 22:31:52 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 22:32:51 --> 404 Page Not Found: admin/Undefined/index
ERROR - 2023-01-21 22:33:14 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 22:33:20 --> 404 Page Not Found: Uploads/profile_img
ERROR - 2023-01-21 22:33:40 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 22:44:27 --> Query error: Expression #10 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'truelysell.r.rating' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `s`.`id`, `s`.`user_id`, `s`.`service_location`, `s`.`service_title`, `s`.`service_amount`, `s`.`mobile_image`, `s`.`about`, `c`.`category_name`, `c`.`category_image`, `r`.`rating`, `sc`.`subcategory_name`, `s`.`currency_code`, `s`.`url`
FROM `services` `s`
LEFT JOIN `categories` `c` ON `c`.`id` = `s`.`category`
LEFT JOIN `subcategories` `sc` ON `sc`.`id` = `s`.`subcategory`
LEFT JOIN `rating_review` `r` ON `r`.`service_id` = `s`.`id`
JOIN `subscription_details` as `sd` ON `sd`.`subscriber_id`=`s`.`user_id`
WHERE `s`.`status` = 1
AND `s`.`status` = 1
GROUP BY `s`.`id`
ORDER BY `s`.`total_views` DESC
 LIMIT 10
ERROR - 2023-01-21 23:58:01 --> 404 Page Not Found: About/index
