  <html>
	<head>
		<title>EPAYLINK Testing</title>
	</head>
	<body bgcolor="#FFFFFF" text="#000000">
		<form method="post" action="https://www.thaiepay.com/epaylink/payment.aspx?lang=en">
			<input type="hidden" name="payso" value="payso" />
			<input type="hidden" name="refno" value="789456123012">
			<input type="hidden" name="merchantid" value="30233565">
			<input type="hidden" name="customeremail" value="saravanakumar.b@dreamguys.co.in">
			<input type="hidden" name="cc" value="00">
			<input type="hidden" name="productdetail" value="Testing Product">
			<input type="hidden" name="total" value="5">
			<br>
			<input type="submit" name="Submit" value="Confirm Order">
		</form>
	</body>
</html>