<body>
	<h5>Hai <?php echo $reply_det['name'];?>,</h5>
	<p><?= $reply_det['reply'];?> .</p>
</body>